package pwr.edu.pl.zwis2017.screen.options;

public interface OnLocalizationDeleted {
    void onItemDeleted(String positionToDelete);
}
