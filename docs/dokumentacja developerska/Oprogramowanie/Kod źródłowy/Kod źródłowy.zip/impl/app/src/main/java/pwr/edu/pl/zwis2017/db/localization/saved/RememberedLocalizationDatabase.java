package pwr.edu.pl.zwis2017.db.localization.saved;

import android.provider.BaseColumns;

public final class RememberedLocalizationDatabase implements BaseColumns {

    public static final String TABLE_NAME = "RememberedLocalization";
    public static final String LOCALIZATION_NAME = "LocalizationName";

}
