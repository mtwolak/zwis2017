package pwr.edu.pl.zwis2017.screen.region.logic;

public class CannotGetGeoApiException extends RuntimeException {

    public CannotGetGeoApiException(Exception e) {
        super(e);
    }
}
