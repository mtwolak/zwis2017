package pwr.edu.pl.zwis2017.screen.maps;


public class CannotCreateMapPickerException extends RuntimeException {

    public CannotCreateMapPickerException(Exception e) {
        super(e);
    }
}
